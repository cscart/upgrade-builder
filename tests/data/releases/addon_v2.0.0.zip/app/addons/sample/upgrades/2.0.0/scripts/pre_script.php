<?php
/**** THIS IS PRE SCRIPT ****/